public class Search {

    public static void main(String[] args) {

            MazeGrid grid;
            boolean pathFound;
            int pathCount=0;
        System.out.println("50 Grid worlds");
            while (pathCount<50){

                grid = new MazeGrid(101,101,0,0,100,100);


                System.out.print(pathCount + "\n");
                System.out.println();
                // forward
                pathFound = grid.AStar(0, 2);

                pathCount++;
                if (pathFound) {

                   grid.showMazeGrid();
                    System.out.print("number of expansions"+grid.getExpansions() + "," + "optimal path cost"+ grid.getOptimalPathCost() + ",");
                    System.out.println();
                    grid.resetPath();

                    // backward
                    grid.AStar(1, 2);
                    System.out.print("number of expansions"+grid.getExpansions() + ","  + "optimal path cost"+grid.getOptimalPathCost() + "\n");
                    //grid.showMazeGrid();
                }

            }
    }




}
