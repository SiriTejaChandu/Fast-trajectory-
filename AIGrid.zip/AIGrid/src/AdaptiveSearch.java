public class AdaptiveSearch {

    public static void main(String[] args) {
        MazeGrid grid;
        Boolean pathfound;
        int pathcount = 0;

        while (pathcount < 1) {
            grid = new MazeGrid(101,101,0,0,100,100);

            // First Search in Adaptive
            pathfound = grid.AdaptiveStarSearch(0,0);

            if (pathfound) {
                pathcount++;

                //g.printGrid();
                System.out.print("Expansions: " +grid.getExpansions() + ", Optimal Path Cost: "+grid.getOptimalPathCost() + "\n");

                grid.resetPath();

                // Second Search, Different Initial State: pass initial state as argument (row, column)
                grid.AdaptiveStarSearch(40, 35);
                System.out.print("Expansions: " + grid.getExpansions() + "Optimal Path Cost: "+ grid.getOptimalPathCost() + "\n");
            }

        }

    }

}
