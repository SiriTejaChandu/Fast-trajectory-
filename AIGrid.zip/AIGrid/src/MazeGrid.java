import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;
import  java.lang.Math;

public class MazeGrid {

    GridNode [][] gridworld;
    int rw_max,cl_max;
    boolean foundPath;
    ArrayList<GridNode> openList;
    ArrayList<GridNode> currentList = new ArrayList<GridNode>();
    Stack<GridNode> closeList;
    Stack<GridNode> shortestPath;
    GridNode current ;
    GridNode start;
    GridNode target;
    int expansions;
    boolean result;
    boolean isAdaptive=false;
    boolean second=false;
    public MazeGrid(int rw, int cl, int start_rw, int start_cl, int target_rw, int target_cl) {

        if(rw < 1){
            rw_max=101;
        }
        if(cl < 1){
            cl_max=101;
        }
        rw_max=rw-1;
        cl_max=cl-1;
        this.gridworld=new GridNode[rw][cl];
        setMazeGrid();

        // check for start node
        if(start_rw > rw || start_cl > cl || start_rw < 0 || start_cl < 0){
            start = this.gridworld[0][0];
        }else{
            start = this.gridworld[start_rw][start_cl];
        }

        // check for target node
        if(target_rw > rw || target_cl > cl || target_rw < 0 || target_cl < 0){
            target = this.gridworld[rw_max][cl_max];
        }else{
            target = this.gridworld[target_rw][target_cl];
        }

        calculateHvalue();

        openList = new ArrayList<GridNode>();
        closeList = new Stack<GridNode>();
        shortestPath = new Stack<GridNode>();

        start.isNodeBlocked = false;
        target.isNodeBlocked = false;
        this.current= start;
        expansions=0;
        foundPath=false;

    }

    public void calculateHvalue() {
        for(int i=0;i<=rw_max;i++){
            for(int j=0;j<=cl_max;j++){
                this.gridworld[i][j].hval = Math.abs(target.rw - i) + Math.abs(target.cl - j);

            }

    }}

    public void setMazeGrid()
    {

    for(int i=0;i<=rw_max;i++){
            for(int j=0;j<=cl_max;j++){
                this.gridworld[i][j] = new GridNode(i,j,0,blockedValue(),rw_max,cl_max);
            }
        }

    }

    public boolean blockedValue(){
        return Math.random() * 10 < 3 ? true : false;
    }

    public void showMazeGrid() {

        for(int i=0;i<=rw_max;i++){
            System.out.print(i +"\t");
            for(int j=0; j<= cl_max;j++) {
                if (this.gridworld[i][j].isNodeBlocked) {
                    System.out.print("X");
                } else if (this.gridworld[i][j].path) {
                    System.out.print("O");
                } else {
                    System.out.print("_");
                }

            }
            System.out.print("\n");
        }
    }


    /**
     * Helper function to perform A* Search forward or backwards
     *
     * @param direction
     *            0 for forward, 1 for backward
     * @return True if path if found, false if not
     */
    public Boolean AStar(int direction, int priority) {
        Boolean result = false;

        expansions = 0;

        if (direction == 0) { // forward
            current = start;
            calculateHvalue();
            result = AStarSearch(0, priority);
            openList.clear();

            while (!closeList.isEmpty()) {
                closeList.pop();
            }

            return result;
        } else if (direction == 1) { // backward

            // swap initial and goal
            GridNode temp = target;
            target = start;
            start = temp;
            calculateHvalue();
            current = start;

            result = AStarSearch(0, priority);
            openList.clear();

            while (!closeList.isEmpty()) {
                closeList.pop();
            }

            // swap initial and goal back
            temp = target;
            target = start;
            start = temp;

            return result;
        } else { // error input
            return false;
        }
    }
   /* *
     * Perform the AStar Search and alter the Grid to reflect the optimal path found
     */
   /* private Boolean AStarSearch(int step, int priority) {
        expansions = step;
        this.gridworld[current.rw][current.cl].hval = current.hval;
        this.gridworld[current.rw][current.cl].gval = current.gval;
        this.gridworld[current.rw][current.cl].fval = current.fval;
        closeList.push(current);

        // base case
        if (target.equals(current)) {
            foundPath = true;
            return foundPath;
        }

        // add neighbors to opened list
       // GridNode temp;

         leftNode(current);
         upNode(current);
         rightNode(current);
         downNode(current);

        if (openList.size() < 1) {
            return foundPath;
        }

        // tie breaking and sorting
        if (priority == 1) {
            Collections.sort(openList, GridNode.BigG); // priority for smaller g values
        } else {
            Collections.sort(openList, GridNode.SmallG); // priority for larger g values
        }

        current = openList.get(0);
        openList.remove(0);

         AStarSearch(step + 1, priority);

        // all done with the planning phase
        // trail up from the currNode should be the optimal path
            optimalPath(current);


        return foundPath; // end
    }*/
    private Boolean AStarSearch(int step, int priority) {
        while (this.current != target || openList.size() < 1) {

        expansions = step;
        this.gridworld[current.rw][current.cl].hval = current.hval;
        this.gridworld[current.rw][current.cl].gval = current.gval;
        this.gridworld[current.rw][current.cl].fval = current.fval;
        closeList.push(current);

            if(target.equals(current)){
                break;
            }


        // add neighbors to opened list
        // GridNode temp;

        leftNode(current);
        upNode(current);
        rightNode(current);
        downNode(current);
            if (openList.size() < 1){
                break;
            }

        // tie breaking and sorting
        if (priority == 1) {
            Collections.sort(openList, GridNode.BigG); // priority for smaller g values
        } else {
            Collections.sort(openList, GridNode.SmallG); // priority for larger g values
        }
        if(current!=null){
        current = openList.get(0);
        openList.remove(0);
          //  if(currentList != null)
            currentList.add(current);
        }
        step = step + 1;
    }

        // all done with the planning phase
        // trail up from the currNode should be the optimal path

        if (target.equals(current)) {
            optimalPath(currentList);
            foundPath = true;
            return foundPath;
        }

        if (openList.size() < 1) {
            return foundPath;
        }

        return foundPath; // end
    }


    public Boolean AdaptiveStarSearch(int start_rw, int start_cl) {
        Boolean ret = false;

        expansions = 0;

        // always forward
        current = gridworld[start_rw][start_cl];
        if (!isAdaptive) {
            calculateHvalue();
            isAdaptive = true;
        } else {
            second = true;
        }
        ret = AdaptiveSearch(0);
        openList.clear();

        // Adaptive Search:
        if (ret == true) {
            GridNode temp;
            while (!closeList.isEmpty()) {
                temp = closeList.pop();
                int tempH = this.gridworld[temp.rw][temp.cl].hval;
                this.gridworld[temp.rw][temp.cl].hval = this.target.getG() - temp.getG();
                if ((tempH != this.gridworld[temp.rw][temp.cl].hval)) {
                    /*
                     * System.out.print("Node: " + temp + " changed h from " + tempH);
                     * System.out.print(" to " + this.grid[temp.row][temp.column].h + "\n");
                     */
                }
            }
        }
        return ret;
    }
    /**
     * Perform the Adaptive Search and alter the Grid to reflect the optimal
     * path found
     */
    private Boolean AdaptiveSearch(int step) {

        while (this.current != target || openList.size() < 1) {
            expansions = step;
        this.gridworld[current.rw][current.cl].hval = current.hval;
        this.gridworld[current.rw][current.cl].gval = current.gval;
        this.gridworld[current.rw][current.cl].fval = current.fval;
        closeList.push(current);

        // base case
        if (target.equals(current)) {
            break;
        }

        // add neighbors to opened list
        // add neighbors to opened list
        // GridNode temp;

        leftNode(current);
        upNode(current);
        rightNode(current);
        downNode(current);

        if (openList.size() < 1) {
            break;
        }

        Collections.sort(openList, GridNode.BigG); // priority for larger g values
            if(current!=null){
                current = openList.get(0);
                openList.remove(0);
                //  if(currentList != null)
                currentList.add(current);
            }
      /*  current = openList.get(0);
        openList.remove(0);
            if(currentList != null)
                currentList.add(current);*/

        //AdaptiveSearch(step + 1);
            step = step+1;

    }
        // all done with the planning phase
        // trail up from the currNode should be the optimal path

       /* if (current != null) {
            this.gridworld[current.rw][current.cl].path = true;

            shortestPath.push(current);
            current = current.getParent();
        }*/

        // base case
        if (target.equals(current)) {
            foundPath = true;
            optimalPath(currentList);
            return foundPath;
        }
        if (openList.size() < 1) {
            return foundPath;
        }
        return foundPath; // end


    }









  /*  private void optimalPath(GridNode current) {
        if (current != null) {
            this.gridworld[current.rw][current.cl].path = true;
            shortestPath.push(current);
            current = current.getParent();
        }
    }*/

    private void optimalPath(ArrayList<GridNode> currentList) {
        int size;


        if (currentList != null) {
            size= currentList.size();
            for(int i=size-1;i>=0 ; i--){
            this.gridworld[currentList.get(i).rw][currentList.get(i).cl].path = true;
            shortestPath.push(currentList.get(i));
            GridNode n = currentList.get(i) ;
            n = n.getParent();
        }}
    }
    private void leftNode(GridNode current) {
        GridNode temp;
        if ((this.current.cl > 0 && !this.gridworld[this.current.rw][this.current.cl - 1].isNodeBlocked) ? true :false) {
            temp = this.gridworld[this.current.rw][this.current.cl - 1];
            if (!closeList.contains(temp)) { // don't update g value if in closed list
                temp.updateG(this.current.getG() + 1); // update node's g and f values
                addToOpenedList(temp);
            }
        }
    }

    private void upNode(GridNode current) {
        GridNode temp;
        if ((this.current.rw > 0 && !this.gridworld[this.current.rw - 1][this.current.cl].isNodeBlocked) ? true :false){
            temp = this.gridworld[this.current.rw - 1][this.current.cl]; // get the up node
            if (!closeList.contains(temp)) { // don't update g value if in closed list
                temp.updateG(this.current.getG() + 1); // update node's g and f values
                addToOpenedList(temp);
            }
        }
    }

    private void rightNode(GridNode current) {
        GridNode temp;
        if ((this.current.cl < cl_max && !this.gridworld[this.current.rw][this.current.cl + 1].isNodeBlocked)? true :false){
            temp = this.gridworld[this.current.rw][this.current.cl + 1];; // get the right node
            if (!closeList.contains(temp)) { // don't update g value if in closed list
                temp.updateG(this.current.getG() + 1); // update node's g and f values
                addToOpenedList(temp);
            }
        }
    }

    private void downNode(GridNode current) {
        GridNode temp;
        if ((this.current.rw < rw_max && !this.gridworld[this.current.rw + 1][this.current.cl].isNodeBlocked)? true :false) {
            temp =  this.gridworld[this.current.rw + 1][this.current.cl]; // get the down node
            if (!closeList.contains(temp)) { // don't update g value if in closed list
                temp.updateG(this.current.getG() + 1); // update node's g and f values
                addToOpenedList(temp);
            }
        }
    }


    /**
     * Add a node to Opened List only if new node has smaller f value
     *
     * @param n
     */
    public void addToOpenedList(GridNode n) {
        if (openList.contains(n)) {
            if (openList.get(openList.indexOf(n)).getF() > n.getF()) { // add smaller version of node
                openList.remove(openList.indexOf(n));
                n.setParent(current);
                this.gridworld[n.rw][n.cl].setParent(this.gridworld[current.rw][current.cl]);
                openList.add(n);
            }
        } else {
            n.setParent(current);
            this.gridworld[n.rw][n.cl].setParent(this.gridworld[current.rw][current.cl]);
            openList.add(n);
        }

    }

    /**
     * Print the cost of the optimal path found
     */
    public int getOptimalPathCost() {
        int count = 0;
        while (!shortestPath.isEmpty()) {
            count++;
            shortestPath.pop();
        }
        return count;
    }

    public int getExpansions() {
        return expansions;
    }

    /**
     * reset path variable of every node in grid
     */
    public void resetPath() {
        for (int i = 0; i <= rw_max; i++) {
            for (int j = 0; j <= cl_max; j++) {
                this.gridworld[i][j].path = false;
                this.gridworld[i][j].parentNode = null;
            }
        }
        expansions = 0;
    }
}
